#include <iostream>
#include <iomanip>
using namespace std;

class BankingApp {
public:
    BankingApp(double initialDeposit, double monthlyDeposit, double annualInterest, int numYears);
    void DisplayBalanceWithoutDeposits() const;
    void DisplayBalanceWithDeposits() const;

private:
    double initialDeposit;
    double monthlyDeposit;
    double annualInterest;
    int numYears;
};

BankingApp::BankingApp(double initDeposit, double monthDeposit, double interestRate, int years)
    : initialDeposit(initDeposit), monthlyDeposit(monthDeposit), annualInterest(interestRate), numYears(years) {}

void BankingApp::DisplayBalanceWithoutDeposits() const {
    cout << "Balance and Interest Without Additional Monthly Deposits" << endl;
    cout << "=========================================================" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;

    double balance = initialDeposit;
    for (int year = 1; year <= numYears; ++year) {
        double earnedInterest = balance * (annualInterest / 100);
        balance += earnedInterest;
        cout << year << "\t" << fixed << setprecision(2) << balance << "\t\t" << earnedInterest << endl;
    }
}

void BankingApp::DisplayBalanceWithDeposits() const {
    cout << "Balance and Interest With Additional Monthly Deposits" << endl;
    cout << "=======================================================" << endl;
    cout << "Year\tYear End Balance\tYear End Earned Interest" << endl;

    double balance = initialDeposit;
    for (int year = 1; year <= numYears; ++year) {
        double earnedInterest = 0;
        for (int month = 1; month <= 12; ++month) {
            double monthlyInterest = (balance + monthlyDeposit) * (annualInterest / 100 / 12);
            earnedInterest += monthlyInterest;
            balance += monthlyDeposit + monthlyInterest;
        }
        cout << year << "\t" << fixed << setprecision(2) << balance << "\t\t" << earnedInterest << endl;
    }
}

int main() {
    double initialDeposit, monthlyDeposit, annualInterest;
    int numYears;

    cout << "Welcome to Airgead Banking App" << endl;
    cout << "Enter Initial Deposit Amount: ";
    cin >> initialDeposit;
    cout << "Enter Monthly Deposit Amount: ";
    cin >> monthlyDeposit;
    cout << "Enter Annual Interest Rate (in %): ";
    cin >> annualInterest;
    cout << "Enter Number of Years: ";
    cin >> numYears;

    BankingApp app(initialDeposit, monthlyDeposit, annualInterest, numYears);

    cout << endl;
    app.DisplayBalanceWithoutDeposits();
    cout << endl;
    app.DisplayBalanceWithDeposits();

    return 0;
}
